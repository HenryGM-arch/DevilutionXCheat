#include "cheats.h"
#include "player.h"
#include "items/ItemSpawner.h"
#include "op_items/op_items.h"

namespace devilution {

void EnableGodMode()
{
    auto &player = Players[MyPlayerId];
    player._pHitPoints = 9999;
    player._pMaxHP = 9999;
}

void MaxStats()
{
    auto &player = Players[MyPlayerId];
    player._pStrength = 255;
    player._pDexterity = 255;
    player._pMagic = 255;
    player._pVitality = 255;
}

void GiveGold()
{
    auto &player = Players[MyPlayerId];
    player._pGold = 500000;
}

void GiveClassOPItems()
{
    auto &player = Players[MyPlayerId];
    GiveOverpoweredItems(player); // Implementado en op_items.cpp
}

void OpenItemSpawner()
{
    SpawnCustomItem(); // Implementado en ItemSpawner.cpp
}

} // namespace devilution