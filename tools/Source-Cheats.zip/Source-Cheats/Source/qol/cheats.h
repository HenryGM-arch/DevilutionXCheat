#pragma once

namespace devilution {

void EnableGodMode();
void MaxStats();
void GiveGold();
void GiveClassOPItems();
void OpenItemSpawner();

} // namespace devilution