#include "all.h"
#include "qol/cheats.h" // incluir tu cheats.h

namespace devilution {

void GameMenuCheats()
{
    if (ImGui::Begin("Cheats Menu")) {
        if (ImGui::Button("God Mode")) {
            EnableGodMode();
        }
        if (ImGui::Button("Max Stats")) {
            MaxStats();
        }
        if (ImGui::Button("Give Gold")) {
            GiveGold();
        }
        if (ImGui::Button("Class OP Items")) {
            GiveClassOPItems();
        }
        if (ImGui::Button("Item Spawner")) {
            OpenItemSpawner();
        }
    }
    ImGui::End();
}

} // namespace devilution