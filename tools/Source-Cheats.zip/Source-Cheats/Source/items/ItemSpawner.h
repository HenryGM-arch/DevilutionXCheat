#pragma once

namespace devilution {

void SpawnCustomItem();

} // namespace devilution