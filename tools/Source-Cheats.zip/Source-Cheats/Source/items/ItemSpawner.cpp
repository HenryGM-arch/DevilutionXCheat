#include "ItemSpawner.h"
#include "itemdat.h"
#include "items.h"
#include "player.h"

namespace devilution {

void SpawnCustomItem()
{
    ItemStruct newItem;
    memset(&newItem, 0, sizeof(newItem));

    newItem._iSeed = SDL_GetTicks();
    newItem._iCreateInfo = ICURS_SWORD;
    newItem._itype = ITYPE_SWORD;
    newItem._iMagical = true;
    newItem._iName = "⚔ Spawner Sword ⚔";
    newItem._iMinDam = 200;
    newItem._iMaxDam = 300;
    newItem._iAC = 100;
    newItem._iCharges = 50;

    auto &player = Players[MyPlayerId];
    player.InvList[player._pNumInv++] = newItem;
}

} // namespace devilution