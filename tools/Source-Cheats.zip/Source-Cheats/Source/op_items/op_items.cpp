#include "items.h"
#include "player.h"

namespace devilution {

void GiveOverpoweredItems(PlayerStruct &player)
{
    ItemStruct newItem;
    memset(&newItem, 0, sizeof(newItem));

    newItem._iSeed = SDL_GetTicks();
    newItem._iCreateInfo = ICURS_SHIELD;
    newItem._itype = ITYPE_SHIELD;
    newItem._iName = "🛡 OP Shield";
    newItem._iAC = 500;
    newItem._iMaxDam = 0;

    player.InvList[player._pNumInv++] = newItem;
}

} // namespace devilution